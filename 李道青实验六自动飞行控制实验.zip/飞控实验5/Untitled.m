clc; clear;
data = datcomimport('datcom.out'); 

ft = 0.3048;
lb = 0.476;
h = 8000*ft;
V = 430.91*ft;
m = 9000*lb;
I_x = 28408;
I_y = 32463;
I_z = 57549;
I_xz = 3937;
S_w = 320.8*(ft^2);
b = 51.7*ft;
c_A = 6.75*ft;
T_v = 0;
T_d_T = 100000;
g = 9.8;
%Q = (1.8967e+03)*lb/(ft^2);
Q=7802.7;
C_L_d_e = 0;
C_m_d_e = (data{1,3}.dcm_sym(6) - data{1,3}.dcm_sym(4))/(10/57.3);
C_m_q = data{1,1}.cmq(1);
C_D = data{1,1}.cd(6);
C_L_a = data{1,1}.cla(6);
C_m_a_d = data{1,1}.cmad(6);
C_m_a = data{1,1}.cma(6);
C_Y_b = data{1,1}.cyb(1);
C_n_b = data{1,1}.cnb(1);
C_l_b = data{1,1}.clb(6);
C_n_p = data{1,1}.cnp(6);
C_l_p = data{1,1}.clp(6);
C_n_r = data{1,1}.cnr(6);
C_l_r = data{1,1}.clr(6);
C_n_d_a = data{1,2}.cn_asy(6,1)/(10/57.3);
C_l_d_a = data{1,2}.clroll(1)/(10/57.3);

Z_d_e = -Q*S_w*C_L_d_e/m;
M_d_e = Q*S_w*c_A*C_m_d_e/I_y;
M_q = Q*S_w*c_A*c_A*C_m_q/(I_y*2*V);
Z_a = -Q*S_w*(C_D+C_L_a)/m;
M_a_d = Q*S_w*c_A*c_A*C_m_a_d/(I_y*2*V);
M_a = Q*S_w*c_A*C_m_a/I_y;

Y_b = Q*S_w*C_Y_b/m;
N_b = Q*S_w*b*C_n_b/I_z;
L_b = Q*S_w*b*C_l_b/I_x;
N_p = Q*S_w*b*b*C_n_p/(I_z*2*V);
L_p = Q*S_w*b*b*C_l_p/(I_x*2*V);
N_r = Q*S_w*b*b*C_n_r/(I_z*2*V);
L_r = Q*S_w*b*b*C_l_r/(I_x*2*V);
i_r = I_xz/I_x;
i_p = I_xz/I_z;
N_d_a = Q*S_w*b*C_n_d_a/I_z;
L_d_a = Q*S_w*b*C_l_d_a/I_x;
N_d_r = Q*S_w*b*(-0.0031*57.3) / I_z;
L_d_r = Q*S_w*b*(0.00057*57.3) / I_x;

A = [Y_b/V, 0, -1, -g/V;
    (i_r*N_b+L_b)/(1-i_p*i_r), (i_r*N_p+L_p)/(1-i_p*i_r), (i_r*N_r+L_r)/(1-i_p*i_r), 0;
    (i_p*L_b+N_b)/(1-i_p*i_r), (i_p*L_p+N_p)/(1-i_p*i_r), (i_p*L_r+N_r)/(1-i_p*i_r), 0;
    0, 1, 0, 0]
B = [0, 0;
    (i_r*N_d_a+L_d_a)/(1-i_p*i_r), (i_r*N_d_r+L_d_r)/(1-i_p*i_r);
    (i_p*L_d_a+N_d_a)/(1-i_p*i_r), (i_p*L_d_r+N_d_r)/(1-i_p*i_r);
    0, 0]
A1 = [Y_b/V, 0, -1, -g/V, 0, 0, 0, 0, 0;
    (i_r*N_b+L_b)/(1-i_p*i_r), (i_r*N_p+L_p)/(1-i_p*i_r), (i_r*N_r+L_r)/(1-i_p*i_r), 0, (i_r*N_d_a+L_d_a)/(1-i_p*i_r), (i_r*N_d_r+L_d_r)/(1-i_p*i_r), 0, 0, 0;
    (i_p*L_b+N_b)/(1-i_p*i_r), (i_p*L_p+N_p)/(1-i_p*i_r), (i_p*L_r+N_r)/(1-i_p*i_r), 0, (i_p*L_d_a+N_d_a)/(1-i_p*i_r), (i_p*L_d_r+N_d_r)/(1-i_p*i_r), 0, 0, 0;
    0, 1, 0, 0, 0, 0, 0, 0, 0;
    0, 0, 0, 0, -20.2, 0, 0, 0, 0;
    0, 0, 0, 0, 0, -20.2, 0, 0, 0;
    0, 0, 1, 0, 0, 0, -1, 0, 0;
    0, -1, 0, 0, 0, 0, 0, 0, 0;
    0, 0, 0, 0, 0, 0, 0, 0, -1
    ];
B1 =[0, 0, 0;
    0, 0, 0;
    0, 0, 0;
    0, 0, 0;
    20.2, 0, 0;
    0, 20.2, 0;
    0, 0, 0;
    1, 0, 0;
    0, 0, 1
    ];
C1 = [1, 0, 0, 0, 0, 0, 0, 0, 0;
    0, 1, 0, 0, 0, 0, 0, 0, 0;
    0, 0, 0, 1, 0, 0, 0, 0, 0;
    0, 0, 1, 0, 0, 0, -1, 0, 0;
    0, 0, 0, 0, 0, 0, 0, 57.3, 0
    ];
D1 = 0;
sys = ss(A1,B1(:,1:2),C1,D1);
Q = diag([10, 5, 5, 10, 20]);
R = eye(2);
[K, S, e] = lqry(sys, Q, R);