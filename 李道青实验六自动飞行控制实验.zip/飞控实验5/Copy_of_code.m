clear;
alldata = datcomimport('datcom.out');
data1 = alldata{1};
data2 = alldata{2};
data3 = alldata{3};
cma=data1.cma;
alpha1=data1.alpha;
g = 9.8; %重力加速度
h = 10000*0.3048; %高度
M_0 = 0.40;
%M_0 = 0.420; %初始马赫数
%V_0 = 460.72*0.3048;  %初始速度
V_0 = 430.91*0.3048;
m = 9000*0.4536; %质量
%%转动惯量
I_x = 28408; I_y = 32463; I_z = 57549; I_xz = 3937;
ir = I_xz/I_x; ip = I_xz/I_z;
S_w = 320.8*0.3048*0.3048; %参考机翼面积
b = 51.7*0.3048; %机翼展长
c_A = 6.75*0.3048; %机翼平均几何弦长
%air_density = 0.9046; %空气密度
%Q = 0.5*air_density*V_0^2 %动压
%Q = 1.8967E+03*0.4536/0.3048^2*9.8;
%Q = 10410;
Q = 7802.7;
T_v = 0;
T_delta_r = 10000;

k = 2*V_0/c_A;
k1 = 2*V_0/b;
k2 = Q*S_w*b/I_x;
k3 = Q*S_w*b/I_z;

%求小导数
C_D = data1.cd(6); %阻力系数
C_LA = data1.cla(6); %升力系数对迎角的偏导
C_MA = data1.cma(6); %纵向静稳定性导数（俯仰力矩系数对迎角的偏导）
C_MAD = data1.cmad(6) %俯仰力矩系数对迎角变化率的偏导
C_MQ = data1.cmq(1) %俯仰力矩对俯仰角速度的偏导

C_L_deltae = data3.dcl_sym(5); %升力系数对升降舵偏角的偏导
C_M_deltae = (data3.dcm_sym(6)-data3.dcm_sym(5))/5; %俯仰力矩系数对升降舵偏角的偏导

C_YB = data1.cyb(1); %侧力对侧滑角的偏导
C_LB = data1.clb(6); %横滚静稳定性导数（滚转力矩系数对侧滑角的偏导）
C_LP = data1.clp(6); %滚转力矩系数对滚转角速度的偏导
C_LR = data1.clr(6); %滚转力矩系数对偏航角速度的偏导
C_L_deltaa = data2.clroll(1)/(10/57.3); %滚转力矩系数对副翼偏转角的偏导
C_L_deltar = 0.00057;  %滚转力矩系数对方向舵偏角的偏导
C_NB = data1.cnb(1); %偏航力矩系数对侧滑角的偏导
C_NP = data1.cnp(6); %偏航力矩系数对滚转角速度的偏导
C_NR = data1.cnr(6); %偏航力矩系数对偏航角速度的偏导
C_N_deltaa = data2.cn_asy(6,1)/(10/57.3); %偏航力矩系数对副翼偏转角的偏导
C_N_deltar = -0.0031; %偏航力矩系数对方向舵偏角的偏导

%求大导数
Z_deltae = -Q*S_w*C_L_deltae/m;
M_deltae = Q*S_w*c_A*C_M_deltae/I_y;
M_q = Q*S_w*c_A/I_y/k*C_MQ;
Z_alpha = -Q*S_w/m*(C_D+C_LA);
M_alphaD = Q*S_w*c_A/I_y/k*C_MAD;
M_alpha = Q*S_w*c_A/I_y*C_MA;


Y_B = Q*S_w/m*C_YB;
L_B = k2*C_LB;
L_P = k2/k1*C_LP;
L_R = k2/k1*C_LR;
L_deltaa = k2*C_L_deltaa;
L_deltar = k2*C_L_deltar;
N_B = k3*C_NB;
N_P = k3/k1*C_NP;
N_R = k3/k1*C_NR;
N_deltaa = k3*C_N_deltaa;
N_deltar = k3*C_N_deltar;

%求纵向短周期运动的简化传递函数
alpha_num = [Z_deltae, V_0*M_deltae-M_q*Z_deltae];
alpha_den = [V_0, -(Z_alpha+V_0*M_q+V_0*M_alphaD),M_q*Z_alpha-V_0*M_alpha];
q_num = [V_0*M_deltae+Z_deltae*M_alphaD, M_alpha*Z_deltae-Z_alpha*M_deltae];
q_den = [V_0, -(Z_alpha+V_0*M_q+V_0*M_alphaD), M_q*Z_alpha-V_0*M_alpha];
%theta_num=[-M_deltae,-M_deltae*]


den = alpha_den/alpha_den(1)
num = alpha_num/alpha_den(1)
%den = alpha_den;
%num = alpha_num;
[A1,B1,C1,D1]=tf2ss(num,den)

%step(tf(num,den))

num1 = q_num/alpha_den(1);
den1= q_den/alpha_den(1);
%num1 = q_num;
%den1= q_den;
step(tf(num1,den1))
num2=[num;num1]
[A2,B2,C2,D2]=tf2ss(num1,den1)



G_a = tf(num, den)
zeta_a=den(2)/(2*sqrt(den(3)))
G_q = tf(num1, den1)

%求横侧向小扰动线性方程
A = [Y_B/V_0, 0, -1, -g/V_0; 
    (ir*N_B+L_B)/(1-ip*ir), (ir*N_P+L_P)/(1-ip*ir), (ir*N_R+L_R)/(1-ip*ir), 0;
    (ip*L_B+N_B)/(1-ip*ir), (ip*L_P+N_P)/(1-ip*ir), (ip*L_R+N_R)/(1-ip*ir), 0;
    0, 1, 0, 0];
B = [0, 0; (ir*N_deltaa+L_deltaa)/(1-ip*ir), (ir*N_deltar+L_deltar)/(1-ip*ir);
    (ip*L_deltaa+N_deltaa)/(1-ip*ir), (ip*L_deltar+N_deltar)/(1-ip*ir); 0, 0];